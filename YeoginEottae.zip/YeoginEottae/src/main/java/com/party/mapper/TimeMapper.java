package com.party.mapper;

public interface TimeMapper {

	String getNow();
	
}
